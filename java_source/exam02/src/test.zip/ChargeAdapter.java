package test;

public interface ChargeAdapter {
	void galaxy();
	void iphone();
}
